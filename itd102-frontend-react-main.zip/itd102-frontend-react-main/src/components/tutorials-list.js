import React, { Component } from 'react'

export default class TutorialsList extends Component {
  render() {
    return (
      <div>tutorials-list</div>
    )
  }
}
